<?php
$g_hostname = 'localhost';
$g_db_type = 'mysql';
$g_database_name = 'bugtracker';
$g_db_username = 'root';
$g_password = '';
$g_signup_use_captcha = OFF;
$g_phpmailer_method = PHPMAILER_METHOD_SMTP;
$g_smtp_host = 'localhost';